﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/******************************

Goals
* NEED TO FIX PROBLEM WHERE SCRIPT CONTINUES IF WE STILL HOVER OVER OBJECT
* shouldn't be able to click another object while current object is active

Stretch Goals
* FIX THE NEED TO HOVER OVER OBJECT FOR SCRIPT TO FINISH (ONPOINTEREXIT)
* IDEALLY FIX HARDCODING OF SCRIPT LINE NUMBERS

********** */
public class MouseOver : MonoBehaviour {

	public Image image;
	public Text text;
	public Text speaker;
	public GameObject Dialogue;
	public string s;
	// Use this for initialization
	void Start () {
		image = this.GetComponent<Image>();
	}

	public void OnPointerEnter(){
		float r = 151/255;
		float g = 182/255;
		float b = 215/255;
		image.color = new Color(r, g, b, 1);
	}

	public void OnPointerExit(){
		image.color = new Color(1, 1, 1,1);
		/*if(this.tag == "Postit" && !Dialogue.GetComponent<Dialogue>().getComp())
		{
			transform.GetChild(0).gameObject.SetActive(false);
		}
		else if(this.tag == "Computer"){
			return;
		}*/
		//Dialogue.SetActive(false);
	}

	public void OnPointerClick(){
			Dialogue.GetComponent<Dialogue>().setCheck(true);
			Dialogue.SetActive(true);
			Dialogue.GetComponent<Dialogue>().speaking = false;
			text.text=s;
			speaker.text="Watchson";
			if(this.tag == "Postit"){
				transform.GetChild(0).gameObject.SetActive(true);
				Dialogue.GetComponent<Dialogue>().viewingObj = true;
				if(Dialogue.GetComponent<Dialogue>().getComp()){
					text.text="He wrote down his passwords on the post-it. What should we do?";
					Dialogue.GetComponent<Dialogue>().setPostIt();
					Dialogue.GetComponent<Dialogue>().setPos(19);
				}
				else{
					text.text="He seems crazy about NBA and is a Cleveland Cavaliers fan...";
				}
			}
			else if (this.tag == "Computer"){
				Dialogue.GetComponent<Dialogue>().setComp();
				if (Dialogue.GetComponent<Dialogue>().getPostIt()){
					text.text="We will try the password!";
				Dialogue.GetComponent<Dialogue>().setPos(26);
				}
				else{
					Dialogue.GetComponent<Dialogue>().setPos(8);
				}
			}
			else{
				Dialogue.GetComponent<Dialogue>().viewingObj = true;
			}
	}
}
