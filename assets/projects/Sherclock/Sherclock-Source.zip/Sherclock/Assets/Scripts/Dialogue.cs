﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dialogue : MonoBehaviour {

	 [SerializeField]
     public Text textBox; //dialogue
	 [SerializeField]
	 public Text speakerBox; //who is speaking
	 public GameObject room;
	 public GameObject dog; //final picture at end
	 public GameObject postit; //post it object
	 public Image headshot; //who is speaking (pic)
	 public bool speaking; //are we talking right now
	 public bool postSeen;
	 public bool compSeen;
	 public bool checkText; //should we read through script
     
	 //Store all your text in this string array
	 [SerializeField]
	 List<string> scripts;
	 [SerializeField]
	 List<string> speakers;
     public int currentlyDisplayingText = -1; //current position in the script

	 public GameObject button1;
	 public GameObject button2;
	 public GameObject button3;
	 [SerializeField]
	 Sprite[] sprites;
	 bool continuer; //are we done with a choice and moving on to scripts
	 public bool viewingObj; //are we looking around the room

	 void Start (){
        if(LoadText.LoadScript("Script")){
			Debug.Log("Loaded");
		}
		speaking = false;
		postSeen = false;
	 }
     void Awake () {
		textBox = transform.GetChild(0).GetComponent<Text>();
		speakerBox = transform.GetChild(1).GetComponent<Text>();
		scripts = LoadText.scripts;
		speakers = LoadText.speakers;
		checkText = true;
		sprites = Resources.LoadAll<Sprite>("Sprites");
		textBox.text = "Press ENTER to continue";
		dog.SetActive(false);
	 }
     void OnEnable(){
		if (checkText){
			StartCoroutine("Listen");
		}
	 }
	 void OnDisable(){
		 if (checkText) StopCoroutine("Listen");
	 }

	 IEnumerator Listen(){ //equivalent to Update function but allows while loop
		while(true){
            if (continuer || ((Input.GetKeyDown(KeyCode.Mouse0) ||
              Input.GetKeyDown(KeyCode.Return)) && !speaking))
            {
				if(postit.gameObject.activeSelf){
					postit.SetActive(false);
				}
				if(viewingObj){
					viewingObj = false;
					this.gameObject.SetActive(false);
					StopAllCoroutines();
				}
				else{
					continuer = false;
                	currentlyDisplayingText++;
                	if (!compSeen && currentlyDisplayingText == 8)
                	{
						headshot.sprite = sprites[2];
                    	room.gameObject.SetActive(true);
                    	this.gameObject.SetActive(false);
                	} //before first computer
                	else if (currentlyDisplayingText == 9)
                	{
						StartCoroutine(AnimateText());
                    	StartChoice();
						break;
               	 	} //choice 1
					else if (currentlyDisplayingText == 14)
                	{
						StartCoroutine(AnimateText());
                    	StartChoice();
						break;
                	} //choice 2
                	else if (currentlyDisplayingText == 19)
                	{
						headshot.sprite = sprites[2];
                    	room.gameObject.SetActive(true);
                    	this.gameObject.SetActive(false);
                	} //end choices
					else if (currentlyDisplayingText == 20)
                	{
						postit.SetActive(false);
						StartCoroutine(AnimateText());
                    	StartChoice();
						break;
                	} //choice 3
                    else if (currentlyDisplayingText == 25)
                    {
                        headshot.sprite = sprites[2];
                        room.gameObject.SetActive(true);
                        this.gameObject.SetActive(false);
                    } //end choices
                    else if (currentlyDisplayingText == 31)
                    {
                        StartCoroutine(AnimateText());
                        StartChoice();
                        break;
                    } //choice 4
                    else if (currentlyDisplayingText == 36)
                    {
                        StartCoroutine(AnimateText());
                        StartChoice();
                        break;
                    } //choice 5
                    else if (currentlyDisplayingText == 47)
                    {
                        StartCoroutine(AnimateText());
                        StartChoice();
                        break;
                    } //choice 6
                    else if (currentlyDisplayingText == 53)
                    {
                        StartCoroutine(AnimateText());
                        StartChoice();
                        break;
                    } //choice 7
                    else if (currentlyDisplayingText == 62)
                    {
                        room.GetComponent<Image>().color = Color.black;
                        StartCoroutine(AnimateText());
                    } //time travelling
                    else if (currentlyDisplayingText == 79)
                    {
                        room.SetActive(false);
                        StartCoroutine(AnimateText());
                    } //done time travelling
                    else if (currentlyDisplayingText == 83)
                    {
                        dog.SetActive(true);
                        StartCoroutine(AnimateText());
                    } //detective office
                    else if (!postSeen && currentlyDisplayingText >= 90)
                    {
                        this.gameObject.SetActive(false);
                        Application.Quit();
                    } //end of text
                    else if (currentlyDisplayingText < scripts.Count)
                    {
                        StartCoroutine(AnimateText());
                    }
                    else
                    {
                        textBox.text = "";
                        speakerBox.text = "";
                    }
				}
            } //end check for return key
			yield return null;
		}
     }

	 void StartChoice(){
		 StopCoroutine("Listen");
		 button1.SetActive(true);
		 button2.SetActive(true);
		 button3.SetActive(true);
		 speaking = true;
		 button1.GetComponentInChildren<Text>().text = scripts[currentlyDisplayingText + 1];
		 button2.GetComponentInChildren<Text>().text = scripts[currentlyDisplayingText + 2];
		 button3.GetComponentInChildren<Text>().text = scripts
		 	[currentlyDisplayingText + 3];
	 }

	 public void EndChoice(){
		 currentlyDisplayingText += 3;
		 checkText = true;
		 speaking = false;
		 continuer = true;
		 //StartCoroutine("AnimateText");
		 StartCoroutine("Pause");
	 }

	 public void Button1(){
		 Score.updateScore(int.Parse(speakers[currentlyDisplayingText + 1]));
		 button1.SetActive(false);
		 button2.SetActive(false);
		 button3.SetActive(false);
		 switch (currentlyDisplayingText){
			 case 14:
			 	speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "I don't think so. If he hadn't signed out, we would already have access to his accounts.";
			 	EndChoice();
			 	break;
			case 20:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Good call.";
			 	EndChoice();
				break;
			case 36:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Do you really think this is the main reason?";
			 	EndChoice();
				break;
			case 47:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Are you sure? There might be someone like us who could hack his accounts again.";
			 	EndChoice();
				break;
			case 53:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Don’t laugh at him! You aren’t solving the problem.";
			 	EndChoice();
				break;
			 default:
			 	textBox.text = "Hmmm...";
				 speakerBox.text = "WATCHSON";
				 headshot.sprite = sprites[2];
				 EndChoice();
				 break;
		 }
	 }
	 public void Button2(){
		 Score.updateScore(int.Parse(speakers[currentlyDisplayingText + 2]));
		 button1.SetActive(false);
		 button2.SetActive(false);
		 button3.SetActive(false);
		 switch (currentlyDisplayingText){
			 case 14:
			 	speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "I don't think so. It works on my accounts.";
			 	EndChoice();
			 	break;
			case 20:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Are you sure? If someone sees that, he or she might be able to hack into his account.";
			 	EndChoice();
				break;
			case 36:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Yes, you're right. But I think using the same password is a bigger issue.";
			 	EndChoice();
				break;
			case 47:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "That is correct!";
			 	EndChoice();
				break;
			case 53:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Do you think that can actually keep him secure online?";
			 	EndChoice();
				break;
			 default:
			 	textBox.text = "Hmmm...";
				 speakerBox.text = "WATCHSON";
				 headshot.sprite = sprites[2];
				 EndChoice();
				 break;
		 }
	 }

	 public void Button3(){
		 Score.updateScore(int.Parse(speakers[currentlyDisplayingText + 3]));
		 button1.SetActive(false);
		 button2.SetActive(false);
		 button3.SetActive(false);
		 switch (currentlyDisplayingText){
			 case 14:
			 	speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "You're right.";
			 	EndChoice();
			 	break;
			case 20:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Are you sure? I think we still can give it a try. What do you think?";
			 	EndChoice();
				break;
			case 36:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "I completely agree.";
			 	EndChoice();
				break;
			case 47:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Do you really think so? You can’t even imagine how fast hackers could figure out other passwords once they know one.";
			 	EndChoice();
				break;
			case 53:
				speakerBox.text = "WATCHSON";
			 	headshot.sprite = sprites[2];
			 	textBox.text = "Great idea!";
			 	EndChoice();
				break;
			 default:
			 	textBox.text = "Hmmm...";
				 speakerBox.text = "WATCHSON";
				 headshot.sprite = sprites[2];
				 EndChoice();
				 break;
		 }
	 }

	 public void setPos(int i){
		 currentlyDisplayingText = i;
		 speaking = false;
		 StartCoroutine(Listen());
		 StartCoroutine(AnimateText());
	 }

	 public void setPostIt(){
		 postSeen = true;
	 }
	 public bool getPostIt(){
		 return postSeen;
	 }
	 public bool getComp(){
		 return compSeen;
	 }
	 public void setComp(){
		 compSeen = true;
	 }
	 public void setCheck(bool b){
		 checkText = b;
	 }

     IEnumerator AnimateText(){
		 speaking = true;
         speakerBox.text = speakers[currentlyDisplayingText];
		 switch(speakers[currentlyDisplayingText].Substring(0, 3)){
			 	case "WAT": 
				 	headshot.color = new Color32(255, 255, 255, 255);
				 	headshot.sprite = sprites[2];
				 	break;
				case "STU":
					headshot.color = new Color32(255, 255, 255, 255);
					headshot.sprite = sprites[1];
					break;
				case "YOU":
					headshot.color = new Color32(255, 255, 255, 255);
					headshot.sprite = sprites[0];
					break;
				default:
					headshot.sprite = null;
					headshot.color = new Color32(93, 93, 93, 0);
					break;
	 	 }
         	for (int j = 0; j < (scripts[currentlyDisplayingText].Length + 1); 
			 j++)
         	{
			 	if (currentlyDisplayingText == -1) break;
             	textBox.text = scripts[currentlyDisplayingText].Substring(0, j);
			 	if (j == scripts[currentlyDisplayingText].Length){
			    	speaking = false;
			 	}
			 	yield return new WaitForSeconds(.005f);
         	}
     }

	 IEnumerator Pause(){
		 yield return new WaitForSeconds(1f);
		 StartCoroutine("Listen");
	 }
}