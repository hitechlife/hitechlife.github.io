using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;
 
// taken from https://gamedevelopertips.com/unity-how-fade-between-scenes/
public class SceneFader : MonoBehaviour {
 
    #region FIELDS
    public Image fadeOutUIImage;
    public float fadeSpeed = 1.5f; 
    public static SceneFader sceneFader;

    void Awake() {
        sceneFader = this;
    }
 
    public enum FadeDirection
    {
        In, //Alpha = 1
        Out // Alpha = 0
    }
    #endregion
 
    // #region MONOBHEAVIOR
    // void OnEnable()
    // {
    //     StartCoroutine(Fade(FadeDirection.Out));
    // }
    // #endregion
         
    #region FADE
    private IEnumerator Fade(FadeDirection fadeDirection) 
    {
        fadeOutUIImage.enabled = true; 
        float alpha = (fadeDirection == FadeDirection.Out)? 1 : 0;
        float fadeEndValue = (fadeDirection == FadeDirection.Out)? 0 : 1;
        if (fadeDirection == FadeDirection.Out) {
            while (alpha >= fadeEndValue)
            {
                SetColorImage (ref alpha, fadeDirection);
                yield return null;
            }
            fadeOutUIImage.enabled = false; 
        } else {
            // fadeOutUIImage.enabled = true; 
            while (alpha <= fadeEndValue)
            {
                SetColorImage (ref alpha, fadeDirection);
                yield return null;
            }
        }
    }
    #endregion
 
    #region HELPERS
    public IEnumerator FadeAndLoadScene(string sceneToLoad) 
    {
        yield return Fade(FadeDirection.In);
        SceneManager.LoadScene(sceneToLoad);
    }

    public IEnumerator FadeInEnd() 
    {
        yield return Fade(FadeDirection.In);
    }

    
    public IEnumerator FadeIn() 
    {
        yield return Fade(FadeDirection.Out);
    }
 
    private void SetColorImage(ref float alpha, FadeDirection fadeDirection)
    {
        fadeOutUIImage.color = new Color (fadeOutUIImage.color.r,fadeOutUIImage.color.g, fadeOutUIImage.color.b, alpha);
        alpha += Time.deltaTime * (1.0f / fadeSpeed) * ((fadeDirection == FadeDirection.Out)? -1 : 1) ;
    }
    #endregion
}