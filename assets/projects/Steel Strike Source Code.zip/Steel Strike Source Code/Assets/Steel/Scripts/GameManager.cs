﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Yarn.Unity {

public class GameManager : MonoBehaviour
{
    public static GameManager S;
    public List<GameObject> inventory;
    [SerializeField] GameObject inventoryPanel;
    [SerializeField] KeyCode inventoryKey = KeyCode.I;
    [SerializeField] InMemoryVariableStorage variableStorage;
    [SerializeField] GameObject endingScreen;
    bool ending = false;
    // Start is called before the first frame update
    void Start()
    {
        S = this;
        StartCoroutine(SceneFader.sceneFader.FadeIn());
    }

    public VariableStorage VarStore {
        get {
            return variableStorage;
        }
    }

    public void NextScene(string s) {
        StartCoroutine(SceneFader.sceneFader.FadeAndLoadScene(s));
    }

    public void UpdateInventory(Sprite s) {
        foreach (GameObject g in inventory) {
            var sr = g.GetComponent<Image>();
            if (sr.sprite == null) {
                sr.sprite = s;
                sr.preserveAspect = true;
                g.SetActive(true);
                return;
            }
        }
    }

    public int InventoryCount() {
        int count = 0;
        foreach (GameObject g in inventory) {
            var sr = g.GetComponent<Image>();
            if (sr.sprite != null) {
                count++;
            }
        }
        return count;
    }

    public void TheEnd() {
        StartCoroutine(EndingSequence());
    }

    IEnumerator EndingSequence() {
        Task t = new Task(SceneFader.sceneFader.FadeInEnd());
        endingScreen.SetActive(true);
        yield return new WaitUntil(() => t.Running == false);
        endingScreen.GetComponent<Image>().enabled = false;
    }

    public void RemoveInventory(int i) {
        inventory[i].GetComponent<Image>().sprite = null;
        inventory[i].SetActive(false);
    }

    public void Quit() {
        Application.Quit();
    }

    // Update is called once per frame
    void Update()
    {
        if (!ending && Input.GetKeyDown(inventoryKey)) {
            inventoryPanel.SetActive(!inventoryPanel.activeSelf);
        }
    }
}
}
