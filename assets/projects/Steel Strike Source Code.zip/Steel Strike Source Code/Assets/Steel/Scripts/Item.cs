using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;
using System.Globalization;

namespace Yarn.Unity.Example {
    public class Item : MonoBehaviour {
        public Sprite[] sprites;
        public GameObject player;
        public GameObject toSpawn;

        [YarnCommand("hideobject")]
        public void DisappearSelf() {
            this.gameObject.SetActive(false);

        }

        [YarnCommand("showobject")]
        public void ShowSelf() {
            this.gameObject.SetActive(true);
        }

        [YarnCommand("showchild")]
        public void ShowChild() {
            transform.GetChild(0).gameObject.SetActive(true);
        }

        [YarnCommand("inventorycount")]
        public void CountInventory() {
            VariableStorage varStore = GameManager.S.VarStore;
            varStore.SetValue("$RetVal", new Yarn.Value(GameManager.S.InventoryCount()));
            Debug.Log(GameManager.S.InventoryCount());
        }

        [YarnCommand("changesprite")]
        public void ChangeSprite(string s) {
            foreach(var info in sprites) {
                if (info.name == s) {
                    GetComponent<SpriteRenderer>().sprite = info;
                    return;
                }
             }
             Debug.Log("couldn't find sprite to switch");
        }

        [YarnCommand("growsmall")]
        public void GrowSmall() {
            transform.localScale *= 0.25f;
        }

        [YarnCommand("togglesprite")]
        public void ToggleSprite() {
            GetComponent<SpriteRenderer>().enabled = !GetComponent<SpriteRenderer>().enabled;
        }

        [YarnCommand("flipsprite")]
        public void FlipSprite() {
            GetComponent<SpriteRenderer>().flipX = !GetComponent<SpriteRenderer>().flipX;
        }

        [YarnCommand("addinventory")]
        public void AddToInventory() {
            var sr = GetComponent<SpriteRenderer>();
            GameManager.S.UpdateInventory(sr.sprite);
            this.gameObject.SetActive(false);
        }

        [YarnCommand("removeinventory")]
        public void RemoveInventory(string index) {
            GameManager.S.RemoveInventory(Int32.Parse(index));
        }

        [YarnCommand("print")]
        public void SaySomething(string s){
            Debug.Log(s);
        }

        [YarnCommand("loadscene")]
        public void nextScene(String s) {
            GameManager.S.NextScene(s);
        }

        [YarnCommand("movetoplayer")]
        public void MoveToPlayer() {
            StartCoroutine(MoveSelf(5f, 0.2f));
        }

        [YarnCommand("movetoplayerparams")]
        public void MoveToPlayer(string fl, string f2) {
            StartCoroutine(MoveSelf(float.Parse(fl, CultureInfo.InvariantCulture), float.Parse(f2, CultureInfo.InvariantCulture)));
        }

        [YarnCommand("moveawayplayer")]
        public void MoveAwayPlayer(string fl, string f2) {
            StartCoroutine(MoveSelf(float.Parse(fl, CultureInfo.InvariantCulture), float.Parse(f2, CultureInfo.InvariantCulture)));
        }

        [YarnCommand("spawnsprite")]
        public void SpawnSprite() {
            Instantiate(toSpawn, transform.position - new Vector3(2, 0, 0), Quaternion.identity).SetActive(true);
        }

        private IEnumerator MoveSelf(float f1, float f2) {
            while (Vector3.Distance(transform.position, player.transform.position) > f1) {
                transform.position = Vector3.MoveTowards(transform.position, player.transform.position, f2);
                yield return null;
            }
        }
    }
}
