﻿using System;

[Serializable]
public struct Culture {
    public string Name;
    public string DisplayName;
}
